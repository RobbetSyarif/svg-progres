function s(sel) {
  return document.querySelector(sel);
}

let progres = s(".cn").textContent;
let coun = s(".cn");
let svg = s(".ling");
let leng = 510-102;
let pers = progres++;
let total = pers*leng/100;
let offs =Math.round(510-total);
let hit = 510;
let cn = 0;


let count = setInterval(()=>{
  coun.textContent=cn+"%";
  if (cn == pers) {
    clearInterval(count);
    coun.textContent=cn+"%";
  }
  cn++;
},40)

let hiy = setInterval(()=>{
 svg.style.strokeDashoffset=hit;
 if (hit == offs) {
   clearInterval(hiy);
 }
 hit--;
 console.log(hit +"dari"+ pers);
},10)